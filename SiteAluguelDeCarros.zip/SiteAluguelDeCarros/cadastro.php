<?php
session_start();
if (isset($_SESSION['usuario_id'])) {
  header("Location: index.php");
  exit();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Cadastro de Usuário</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .container {
      max-width: 400px;
      margin: 40px auto;
      background-color: #ffffff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    .container h2 {
      text-align: center;
      margin-bottom: 20px;
      color: #2c3e50;
    }

    .container input,
    .container button {
      width: 100%;
      padding: 12px;
      margin-top: 10px;
      border: 1px solid #ccc;
      border-radius: 5px;
      font-size: 14px;
    }

    .container button {
      background-color: #2980b9;
      color: white;
      font-weight: bold;
      cursor: pointer;
    }

    .container button:hover {
      background-color: #1f5f91;
    }

    .container a {
      display: block;
      text-align: center;
      margin-top: 15px;
      color: #3498db;
      text-decoration: none;
    }

    .container a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<?php include('header.php'); ?>

<div class="container">
  <h2>Cadastro de Novo Usuário</h2>
  <form method="POST" action="salvar_usuario.php">
    <input type="text" name="nome" placeholder="Nome completo" required>
    <input type="email" name="email" placeholder="E-mail" required>
    <input type="password" name="senha" placeholder="Senha" required>
    <button type="submit">Cadastrar</button>
  </form>
  <a href="login.php">Já tem conta? Faça login</a>
</div>

<?php include('footer.php'); ?>

</body>
</html>
