<?php
session_start();
include('conexao.php');

// Somente admin pode cadastrar carros
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
  echo "<script>alert('Acesso negado.'); window.location.href = 'index.php';</script>";
  exit();
}

// Verifica se imagem foi enviada
if (!isset($_FILES['imagem']) || $_FILES['imagem']['error'] !== UPLOAD_ERR_OK) {
  echo "<script>alert('Erro no envio da imagem.'); window.location.href = 'cadastrar_carro.php';</script>";
  exit();
}

// Define caminho de destino
$nome_imagem = basename($_FILES['imagem']['name']);
$destino_web = "img/" . $nome_imagem;
$caminho_completo = "C:\\xampp\\htdocs\\SiteAluguelDeCarros\\" . $destino_web;

// Cria a pasta se não existir
if (!is_dir("img")) {
  mkdir("img", 0777, true);
}

// Move a imagem
if (move_uploaded_file($_FILES['imagem']['tmp_name'], $caminho_completo)) {
  // Prepara e executa a inserção no banco
  $sql = "INSERT INTO carros (marca, modelo, ano, placa, preco_diaria, imagem, caminho_imagem)
          VALUES (?, ?, ?, ?, ?, ?, ?)";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("ssissss",
    $_POST['marca'],
    $_POST['modelo'],
    $_POST['ano'],
    $_POST['placa'],
    $_POST['preco_diaria'],
    $nome_imagem,
    $caminho_completo
  );

  if ($stmt->execute()) {
    echo "<script>alert('Carro cadastrado com sucesso!'); window.location.href = 'cadastrar_carro.php';</script>";
  } else {
    echo "<script>alert('Erro ao salvar no banco: {$stmt->error}'); window.location.href = 'cadastrar_carro.php';</script>";
  }

  $stmt->close();
} else {
  echo "<script>alert('Falha ao mover a imagem para o servidor.'); window.location.href = 'cadastrar_carro.php';</script>";
}

$conn->close();
?>
