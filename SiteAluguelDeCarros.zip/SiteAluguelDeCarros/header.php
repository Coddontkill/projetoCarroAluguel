<?php if (session_status() === PHP_SESSION_NONE) session_start(); ?>
<style>
  .site-header {
    background-color: #2c3e50;
    color: white;
    padding: 10px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
  }

  .site-header .logo {
    display: flex;
    align-items: center;
  }

  .site-header .logo img {
    height: 70px;
    margin-right: 15px;
  }

  .site-header .logo h1 {
    font-size: 1.8rem;
    margin: 0;
  }

  nav.navbar {
    background-color: #34495e;
    text-align: center;
    padding: 10px 0;
  }

  nav.navbar a {
    color: #ecf0f1;
    margin: 0 12px;
    text-decoration: none;
    font-weight: bold;
    transition: color 0.3s ease;
  }

  nav.navbar a:hover {
    color: #f1c40f;
  }

  .user-info {
    font-size: 0.9rem;
    margin-right: 10px;
    color: #bdc3c7;
  }

  @media (max-width: 600px) {
    .site-header {
      flex-direction: column;
      text-align: center;
    }

    .site-header .logo {
      justify-content: center;
    }
  }
</style>

<header class="site-header">
  <div class="logo">
    <img src="img/logo.png" alt="Logo FlexCar">
    <h1>FlexCar</h1>
  </div>
  <?php if (isset($_SESSION['usuario_id'])): ?>
    <div class="user-info">
      Olá, <?= htmlspecialchars($_SESSION['nome']) ?> |
      <a href="logout.php" style="color: #e74c3c; font-weight: bold;">Sair</a>
    </div>
  <?php endif; ?>
</header>

<nav class="navbar">
  <a href="index.php">Início</a>
  <a href="carros.php">Todos os Carros</a>
  <?php if (isset($_SESSION['usuario_id'])): ?>
    <a href="minhas_reservas.php">Minhas Reservas</a>
    <?php if ($_SESSION['tipo'] === 'admin'): ?>
      <a href="cadastrar_carro.php">Cadastrar Carro</a>
      <a href="gerenciar_usuarios.php">Gerenciar Usuários</a>
    <?php endif; ?>
  <?php else: ?>
    <a href="login.php">Login</a>
  <?php endif; ?>
</nav>
