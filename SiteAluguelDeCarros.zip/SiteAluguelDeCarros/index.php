<?php
session_start();
include('conexao.php');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Catálogo de Carros | FlexCar</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(to right, #ece9e6, #ffffff);
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 1200px;
      margin: 60px auto;
      padding: 0 20px;
    }

    h2 {
      text-align: center;
      font-size: 2.5rem;
      color: #2c3e50;
      margin-bottom: 40px;
    }

    .carro-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
      gap: 30px;
    }

    .carro-box {
      background: #fff;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.08);
      overflow: hidden;
      transition: transform 0.3s, box-shadow 0.3s;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .carro-box:hover {
      transform: translateY(-5px);
      box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
    }

    .carro-box img {
      width: 100%;
      height: 200px;
      object-fit: cover;
    }

    .carro-box .content {
      padding: 20px;
      text-align: center;
    }

    .carro-box h3 {
      font-size: 1.4rem;
      color: #34495e;
      margin-bottom: 10px;
    }

    .carro-box p {
      margin: 6px 0;
      font-size: 0.95rem;
      color: #555;
    }

    .carro-box a {
      display: inline-block;
      margin-top: 15px;
      padding: 10px 20px;
      background-color: #27ae60;
      color: white;
      font-weight: bold;
      text-decoration: none;
      border-radius: 5px;
      transition: background-color 0.3s ease;
    }

    .carro-box a:hover {
      background-color: #219150;
    }

    .carro-box .login-msg {
      color: #999;
      font-style: italic;
      margin-top: 15px;
    }

    @media (max-width: 768px) {
      h2 {
        font-size: 2rem;
      }
    }
  </style>
</head>
<body>

<?php include('header.php'); ?>

<div class="container">
  <h2>Catálogo de Carros Disponíveis</h2>

  <div class="carro-grid">
    <?php
    $sql = "SELECT * FROM carros Limit 6";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      while ($carro = $result->fetch_assoc()) {
        $caminhoWeb = str_replace('C:\\xampp\\htdocs', '', $carro['caminho_imagem']);
        $caminhoWeb = str_replace('\\', '/', $caminhoWeb);

        echo "<div class='carro-box'>
                <img src='{$caminhoWeb}' alt='Imagem do carro'>
                <div class='content'>
                  <h3>{$carro['marca']} {$carro['modelo']}</h3>
                  <p><strong>Ano:</strong> {$carro['ano']}</p>
                  <p><strong>Placa:</strong> {$carro['placa']}</p>
                  <p><strong>Preço por dia:</strong> R$ {$carro['preco_diaria']}</p>";

        if (isset($_SESSION['usuario_id'])) {
          echo "<a href='reserva.php?carro_id={$carro['id']}'>Reservar</a>";
        } else {
          echo "<p class='login-msg'>Faça login para reservar</p>";
        }

        echo "</div></div>";
      }
    } else {
      echo "<p style='text-align:center;'>Nenhum carro disponível no momento.</p>";
    }

    $conn->close();
    ?>
  </div>
</div>

<?php include('footer.php'); ?>

</body>
</html>
