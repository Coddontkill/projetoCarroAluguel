<?php
session_start();
include('conexao.php');

$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
$tipo = 'cliente'; // padrão
$ativo = 1;

$sql = "INSERT INTO usuarios (nome, email, senha_hash, tipo, ativo) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssi", $nome, $email, $senha, $tipo, $ativo);

if ($stmt->execute()) {
  $_SESSION['usuario_id'] = $stmt->insert_id;
  $_SESSION['nome'] = $nome;
  $_SESSION['tipo'] = $tipo;
  header("Location: index.php");
} else {
  echo "Erro ao cadastrar: " . $stmt->error;
}

$conn->close();
?>
