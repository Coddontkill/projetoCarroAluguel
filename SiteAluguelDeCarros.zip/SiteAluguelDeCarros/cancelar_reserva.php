<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['usuario_id'])) {
  header('Location: login.php');
  exit();
}

$reserva_id = $_POST['reserva_id'] ?? null;

$sql = "DELETE FROM reservas WHERE id = ? AND usuario_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $reserva_id, $_SESSION['usuario_id']);

if ($stmt->execute()) {
  header('Location: minhas_reservas.php');
  exit();
} else {
  echo "Erro ao cancelar reserva: " . $stmt->error;
}
