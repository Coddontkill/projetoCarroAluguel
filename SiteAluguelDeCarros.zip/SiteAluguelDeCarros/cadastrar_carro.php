<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
  echo "Acesso negado.";
  exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Cadastro de Carros</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .container {
      max-width: 500px;
      margin: 40px auto;
      background-color: #ffffff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .container h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 20px;
    }
    .container label {
      display: block;
      margin-top: 10px;
      font-weight: bold;
    }
    .container input, .container button {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border: 1px solid #ccc;
      border-radius: 5px;
    }
    .container button {
      background-color: #27ae60;
      color: white;
      font-weight: bold;
      margin-top: 20px;
    }
    .container button:hover {
      background-color: #219150;
    }
  </style>
</head>
<body>

<?php include('header.php'); ?>

<div class="container">
  <h2>Cadastro de Novo Carro</h2>
  <form method="POST" action="salvar_carro.php" enctype="multipart/form-data">
    <label>Marca:</label>
    <input name="marca" required>

    <label>Modelo:</label>
    <input name="modelo" required>

    <label>Ano:</label>
    <input name="ano" type="number" required>

    <label>Placa:</label>
    <input name="placa" required>

    <label>Preço Diária (R$):</label>
    <input name="preco_diaria" type="number" step="0.01" required>

    <label>Imagem do Carro:</label>
    <input type="file" name="imagem" accept="image/*" required>

    <button type="submit">Salvar</button>
  </form>
</div>

<?php include('footer.php'); ?>

</body>
</html>
