<?php
session_start();
include('conexao.php');

if (!isset($_SESSION['usuario_id'])) {
  echo "<script>alert('Você precisa estar logado para fazer uma reserva.'); window.location.href = 'login.php';</script>";
  exit();
}

$carro_id = $_GET['carro_id'] ?? null;
if (!$carro_id) {
  echo "<script>alert('Nenhum carro selecionado.'); window.location.href = 'index.php';</script>";
  exit();
}

// Busca o carro selecionado
$sql = "SELECT * FROM carros WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $carro_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
  echo "<script>alert('Carro não encontrado.'); window.location.href = 'index.php';</script>";
  exit();
}

$carro = $result->fetch_assoc();
$caminhoWeb = str_replace('C:\\xampp\\htdocs', '', $carro['caminho_imagem']);
$caminhoWeb = str_replace('\\', '/', $caminhoWeb);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Reservar <?= $carro['marca'] . ' ' . $carro['modelo'] ?> | FlexCar</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .container {
      max-width: 700px;
      margin: 40px auto;
      background-color: #fff;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }
    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 25px;
    }
    .carro-info {
      display: flex;
      gap: 20px;
      margin-bottom: 20px;
      align-items: center;
    }
    .carro-info img {
      width: 220px;
      height: 140px;
      object-fit: cover;
      border-radius: 6px;
    }
    .carro-info div {
      flex: 1;
    }
    label {
      display: block;
      margin-top: 10px;
      font-weight: bold;
    }
    input, button {
      width: 100%;
      padding: 10px;
      margin-top: 5px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    input[readonly] {
      background-color: #f9f9f9;
    }
    button {
      margin-top: 20px;
      background-color: #27ae60;
      color: white;
      font-weight: bold;
      cursor: pointer;
    }
    button:hover {
      background-color: #219150;
    }
  </style>
</head>
<body>

<?php include('header.php'); ?>

<div class="container">
  <h2>Reservar <?= $carro['marca'] . ' ' . $carro['modelo'] ?></h2>

  <div class="carro-info">
    <img src="<?= $caminhoWeb ?>" alt="Imagem do carro">
    <div>
      <p><strong>Marca:</strong> <?= $carro['marca'] ?></p>
      <p><strong>Modelo:</strong> <?= $carro['modelo'] ?></p>
      <p><strong>Ano:</strong> <?= $carro['ano'] ?></p>
      <p><strong>Preço por dia:</strong> R$ <?= $carro['preco_diaria'] ?></p>
    </div>
  </div>

  <form method="POST" action="salvar_reserva.php">
    <input type="hidden" name="usuario_id" value="<?= $_SESSION['usuario_id'] ?>">
    <input type="hidden" name="carro_id" value="<?= $carro['id'] ?>">

    <label>Nome:</label>
    <input name="nome" value="<?= htmlspecialchars($_SESSION['nome']) ?>" readonly>

    <label>Telefone:</label>
    <input name="telefone" required>

    <label>Data de Início:</label>
    <input type="date" name="data_inicio" required>

    <label>Data de Fim:</label>
    <input type="date" name="data_fim" required>

    <button type="submit">Confirmar Reserva</button>
  </form>
</div>

<?php include('footer.php'); ?>

</body>
</html>
