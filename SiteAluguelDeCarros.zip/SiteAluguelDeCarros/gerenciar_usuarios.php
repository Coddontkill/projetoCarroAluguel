<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
  echo "Acesso negado.";
  exit();
}
include('conexao.php');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Gerenciar Usuários</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .container {
      max-width: 900px;
      margin: 40px auto;
      padding: 20px;
      background-color: #fff;
      border-radius: 8px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    .usuario {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #ccc;
      padding: 10px 0;
    }

    .usuario-info {
      flex: 1;
    }

    .usuario-form {
      display: flex;
      align-items: center;
    }

    .usuario-form button {
      padding: 6px 12px;
      border: none;
      background-color: #e67e22;
      color: white;
      border-radius: 4px;
      cursor: pointer;
    }

    .usuario-form button:hover {
      background-color: #d35400;
    }
  </style>
</head>
<body>

<?php include('header.php'); ?>

<div class="container">
  <h2>Gerenciar Usuários</h2>

  <?php
  $sql = "SELECT id, nome, email, tipo, ativo FROM usuarios";
  $result = $conn->query($sql);

  if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
      $nome = htmlspecialchars($row['nome']);
      $email = htmlspecialchars($row['email']);
      $tipo = htmlspecialchars($row['tipo']);
      $ativo = $row['ativo'];

      echo "<div class='usuario'>
              <div class='usuario-info'>
                <strong>{$nome}</strong> ({$email}) - Tipo: {$tipo} - Ativo: {$ativo}
              </div>
              <form class='usuario-form' method='POST' action='toggle_usuario.php'>
                <input type='hidden' name='id' value='{$row['id']}'>
                <input type='hidden' name='ativo' value='" . ($ativo ? 0 : 1) . "'>
                <button type='submit'>" . ($ativo ? "Desativar" : "Ativar") . "</button>
              </form>
            </div>";
    }
  } else {
    echo "<p style='text-align:center;'>Nenhum usuário encontrado.</p>";
  }

  $conn->close();
  ?>
</div>

<?php include('footer.php'); ?>

</body>
</html>
