<?php
session_start();
include('conexao.php');

$email = $_POST['email'];
$senha = $_POST['senha'];

$sql = "SELECT * FROM usuarios WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
  $user = $result->fetch_assoc();

  if ($user['ativo'] == 0) {
    echo "<script>alert('Usuário desativado.'); location.href='login.php';</script>";
    exit();
  }

  if (password_verify($senha, $user['senha_hash'])) {
    $_SESSION['usuario_id'] = $user['id'];
    $_SESSION['nome'] = $user['nome'];
    $_SESSION['tipo'] = $user['tipo'];
    header("Location: index.php");
    exit();
  }
}

echo "<script>alert('Login inválido'); location.href='login.php';</script>";
?>
