<style>
  footer.site-footer {
    background-color: #1f1a1a;
    color: #ccc;
    padding: 50px 20px;
    font-family: 'Segoe UI', sans-serif;
  }

  .footer-container {
    max-width: 1200px;
    margin: auto;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    gap: 30px;
  }

  .footer-column {
    flex: 1;
    min-width: 220px;
  }

  .footer-column h2 {
    font-size: 1.1rem;
    color: #fff;
    margin-bottom: 10px;
  }

  .footer-column p,
  .footer-column a,
  .footer-column address {
    color: #ccc;
    font-size: 0.95rem;
    margin: 6px 0;
    text-decoration: none;
  }

  .footer-column a:hover {
    color: #00ffcc;
  }

  .social-icons a {
    margin-right: 10px;
    font-size: 1.3rem;
    color: #0f0;
  }

  .newsletter input[type="email"] {
    width: 100%;
    padding: 8px;
    background: transparent;
    border: none;
    border-bottom: 1px solid #555;
    color: #ccc;
    margin-bottom: 15px;
  }

  .newsletter input[type="submit"] {
    padding: 10px 25px;
    border: 2px solid #fff;
    background: none;
    color: #fff;
    border-radius: 25px;
    cursor: pointer;
    transition: 0.3s;
  }

  .newsletter input[type="submit"]:hover {
    background-color: #00cc99;
    border-color: #00cc99;
  }

  .footer-bottom {
    text-align: center;
    margin-top: 40px;
    font-size: 0.8rem;
    color: #aaa;
  }

  @media (max-width: 768px) {
    .footer-container {
      flex-direction: column;
      align-items: center;
      text-align: center;
    }
    .footer-column {
      min-width: 100%;
    }
  }
</style>

<footer class="site-footer">
  <div class="footer-container">

    <div class="footer-column">
      <h2>Headquarter</h2>
      <address>
        212 Barrington Court<br>
        New York, ABC 10001
      </address>
      <div class="social-icons">
        <a href="#"><i class="fa fa-facebook-square"></i></a>
        <a href="#"><i class="fa fa-twitter"></i></a>
        <a href="#"><i class="fa fa-instagram"></i></a>
      </div>
    </div>

    <div class="footer-column">
      <h2>Contact Info</h2>
      <p>+1 333 4040 5566</p>
      <a href="mailto:contact@company.com">contact@company.com</a>

      <h2 style="margin-top:20px;">Quick Links</h2>
      <p><a href="index.php">Home</a> | <a href="about-us.php">About Us</a> | <a href="terms.php">Terms</a> | <a href="contact.php">Contact</a></p>
    </div>

    <div class="footer-column newsletter">
      <h2>Newsletter Signup</h2>
      <form method="post" action="#">
        <input type="email" name="email" placeholder="Enter your email" required>
        <input type="submit" value="Send me">
      </form>
      <p><small>* Please note - we do not spam your email.</small></p>
    </div>

  </div>

  <div class="footer-bottom">
    <p>&copy; <?= date('Y') ?> FlexCar. Template baseado em PHPJabbers.</p>
  </div>
</footer>
