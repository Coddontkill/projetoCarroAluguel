<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
  echo "Acesso negado.";
  exit();
}
echo "<h2>Painel de Controle</h2>";
echo "Bem-vindo, usuário tipo: " . $_SESSION['tipo'] . "<br>";

if ($_SESSION['tipo'] === 'admin') {
  echo "<a href='cadastrar_carro.php'>Cadastrar Carro</a><br>
        <a href='ver_reservas.php'>Ver Reservas</a><br>
        <a href='gerenciar_usuarios.php'>Gerenciar Usuários</a><br>";
} else {
  echo "<a href='carros.php'>Ver Carros</a><br>
        <a href='reserva.php'>Reservar Carro</a><br>";
}
echo "<a href='logout.php'>Sair</a>";
?>
