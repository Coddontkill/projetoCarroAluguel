<?php
session_start();
include('conexao.php');

// Redireciona se não estiver logado
if (!isset($_SESSION['usuario_id'])) {
  header('Location: login.php');
  exit();
}

// Consulta reservas do usuário logado
$sql = "SELECT r.*, c.marca, c.modelo FROM reservas r
        JOIN carros c ON r.carro_id = c.id
        WHERE r.usuario_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['usuario_id']);
$stmt->execute();
$reservas = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Minhas Reservas | FlexCar</title>
  <link rel="stylesheet" href="style.css">
  <style>
    h2 {
      text-align: center;
      margin-top: 40px;
      color: #2c3e50;
    }

    table {
      width: 90%;
      margin: 40px auto;
      border-collapse: collapse;
      background: #fff;
      box-shadow: 0 0 12px rgba(0,0,0,0.1);
    }

    th, td {
      padding: 12px 18px;
      text-align: center;
      border-bottom: 1px solid #ddd;
    }

    th {
      background-color: #27ae60;
      color: white;
    }

    tr:hover {
      background-color: #f2f2f2;
    }

    .cancelar-btn {
      background-color: #e74c3c;
      color: white;
      border: none;
      padding: 8px 15px;
      border-radius: 5px;
      cursor: pointer;
      font-weight: bold;
    }

    .cancelar-btn:hover {
      background-color: #c0392b;
    }
  </style>
</head>
<body>

<?php include('header.php'); ?>

<h2>Minhas Reservas</h2>

<table>
  <tr>
    <th>Carro</th>
    <th>Período</th>
    <th>Telefone</th>
    <th>Ações</th>
  </tr>

  <?php while ($r = $reservas->fetch_assoc()): ?>
    <tr>
      <td><?= htmlspecialchars($r['marca'] . ' ' . $r['modelo']) ?></td>
      <td><?= htmlspecialchars($r['data_inicio']) ?> até <?= htmlspecialchars($r['data_fim']) ?></td>
      <td><?= htmlspecialchars($r['telefone']) ?></td>
      <td>
        <form method="POST" action="cancelar_reserva.php" onsubmit="return confirm('Deseja realmente cancelar esta reserva?');">
          <input type="hidden" name="reserva_id" value="<?= $r['id'] ?>">
          <button type="submit" class="cancelar-btn">Cancelar</button>
        </form>
      </td>
    </tr>
  <?php endwhile; ?>
</table>

<?php include('footer.php'); ?>

</body>
</html>
