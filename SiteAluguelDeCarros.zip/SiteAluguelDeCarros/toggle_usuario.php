<?php
session_start();
include('conexao.php');

// Verifica se o usuário está logado como admin
if (!isset($_SESSION['usuario_id']) || $_SESSION['tipo'] !== 'admin') {
  echo "<script>alert('Acesso negado.'); window.location.href = 'index.php';</script>";
  exit();
}

// Valida se os campos foram recebidos
if (!isset($_POST['id']) || !isset($_POST['ativo'])) {
  echo "<script>alert('Dados incompletos para atualização.'); window.location.href = 'gerenciar_usuarios.php';</script>";
  exit();
}

$id = (int) $_POST['id'];
$ativo = (int) $_POST['ativo'];

// Atualiza o status do usuário
$sql = "UPDATE usuarios SET ativo = ? WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ii", $ativo, $id);

if ($stmt->execute()) {
  header("Location: gerenciar_usuarios.php");
} else {
  echo "<script>alert('Erro ao atualizar usuário: {$stmt->error}'); window.location.href = 'gerenciar_usuarios.php';</script>";
}
?>
