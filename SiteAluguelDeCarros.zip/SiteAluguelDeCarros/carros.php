<?php
session_start();
include('conexao.php');
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Carros Disponíveis</title>
  <link rel="stylesheet" href="style.css">
  <style>
    .container {
      max-width: 1200px;
      margin: 30px auto;
      padding: 0 20px;
    }
    .carro-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 20px;
    }
    .carro-box {
      background-color: white;
      border-radius: 8px;
      padding: 15px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      text-align: center;
      transition: transform 0.2s;
    }
    .carro-box:hover {
      transform: scale(1.02);
    }
    .carro-box img {
      width: 100%;
      max-height: 200px;
      object-fit: cover;
      border-radius: 4px;
    }
    .carro-box h3 {
      margin: 10px 0 5px;
    }
    .carro-box p {
      margin: 5px 0;
    }
    .carro-box a {
      display: inline-block;
      margin-top: 10px;
      padding: 8px 15px;
      background-color: #27ae60;
      color: white;
      text-decoration: none;
      border-radius: 4px;
    }
    .carro-box a:hover {
      background-color: #219150;
    }
  </style>
</head>
<body>

<?php include('header.php'); ?>

<div class="container">
  <h2 style="text-align:center;">Carros Disponíveis para Aluguel</h2>

  <div class="carro-grid">
    <?php
    $sql = "SELECT * FROM carros";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
      while($row = $result->fetch_assoc()) {
        // Sanitização
        $marca = htmlspecialchars($row['marca']);
        $modelo = htmlspecialchars($row['modelo']);
        $ano = htmlspecialchars($row['ano']);
        $preco = number_format($row['preco_diaria'], 2, ',', '.');

        // Caminho da imagem convertido para web
        $caminhoWeb = str_replace('C:\\xampp\\htdocs', '', $row['caminho_imagem']);
        $caminhoWeb = str_replace('\\', '/', $caminhoWeb);

        echo "<div class='carro-box'>
          <img src='{$caminhoWeb}' alt='Imagem do carro'>
          <h3>{$marca} {$modelo}</h3>
          <p><strong>Ano:</strong> {$ano}</p>
          <p><strong>Preço:</strong> R$ {$preco}</p>";

        if (isset($_SESSION['usuario_id'])) {
          echo "<a href='reserva.php?carro_id={$row['id']}'>Reservar</a>";
        } else {
          echo "<p style='color: gray;'>Faça login para reservar</p>";
        }

        echo "</div>";
      }
    } else {
      echo "<p style='text-align:center;'>Nenhum carro encontrado.</p>";
    }

    $conn->close();
    ?>
  </div>
</div>

<?php include('footer.php'); ?>

</body>
</html>
