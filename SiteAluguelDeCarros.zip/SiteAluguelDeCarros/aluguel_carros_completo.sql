
-- Criação do banco de dados
DROP DATABASE IF EXISTS aluguel_carros;
CREATE DATABASE aluguel_carros;
USE aluguel_carros;

-- Tabela de usuários
CREATE TABLE usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  tipo ENUM('cliente', 'admin') DEFAULT 'cliente',
  ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de carros
CREATE TABLE carros (
  id INT AUTO_INCREMENT PRIMARY KEY,
  marca VARCHAR(50) NOT NULL,
  modelo VARCHAR(50) NOT NULL,
  ano INT NOT NULL,
  placa VARCHAR(20) NOT NULL UNIQUE,
  preco_diaria DECIMAL(10,2) NOT NULL,
  imagem VARCHAR(255),
  caminho_imagem VARCHAR(255)
);

-- Tabela de reservas
CREATE TABLE reservas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT,
  nome_cliente VARCHAR(100),
  telefone VARCHAR(20),
  carro_id INT,
  data_inicio DATE,
  data_fim DATE,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
  FOREIGN KEY (carro_id) REFERENCES carros(id)
);

-- Inserção de usuários
INSERT INTO usuarios (nome, email, senha_hash, tipo, ativo) VALUES
('Admin Teste', 'admin@flexcar.com', '$2y$10$EXEMPLOHASH', 'admin', 1),
('João Cliente', 'joao@cliente.com', '$2y$10$EXEMPLOHASH2', 'cliente', 1);

-- Inserção de carros
INSERT INTO carros (marca, modelo, ano, placa, preco_diaria, imagem, caminho_imagem) VALUES
('Toyota', 'Corolla', 2020, 'ABC-1234', 199.99, 'corolla.jpg', 'img/corolla.jpg'),
('Volkswagen', 'Gol', 2018, 'DEF-5678', 149.50, 'gol.jpg', 'img/gol.jpg'),
('Fiat', 'Argo', 2021, 'GHI-9012', 170.00, 'argo.jpg', 'img/argo.jpg'),
('Chevrolet', 'Onix', 2022, 'JKL-3456', 180.00, 'onix.jpg', 'img/onix.jpg'),
('Renault', 'Kwid', 2019, 'MNO-7890', 120.00, 'kwid.jpg', 'img/kwid.jpg');

-- Inserção de reservas de exemplo
INSERT INTO reservas (usuario_id, nome_cliente, telefone, carro_id, data_inicio, data_fim) VALUES
(2, 'João Cliente', '99999-9999', 1, '2025-06-15', '2025-06-18'),
(2, 'João Cliente', '99999-9999', 3, '2025-06-21', '2025-06-25');
