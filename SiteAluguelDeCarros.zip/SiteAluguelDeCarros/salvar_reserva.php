<?php
include('conexao.php');

$sql = "INSERT INTO reservas (usuario_id, nome_cliente, telefone, carro_id, data_inicio, data_fim)
        VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ississ",
  $_POST['usuario_id'],
  $_POST['nome'],
  $_POST['telefone'],
  $_POST['carro_id'],
  $_POST['data_inicio'],
  $_POST['data_fim']
);

if ($stmt->execute()) {
  // Redireciona para a lista de reservas
  header("Location: minhas_reservas.php");
  exit();
} else {
  echo "Erro: " . $stmt->error;
}

$conn->close();
?>
